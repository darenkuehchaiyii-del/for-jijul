
const pages=[
`<h2>Hi Jijul🍯</h2><p>I've been wanting to tell you something…</p><button onclick='next()'>Open it ✨</button>`,
`<h2>Will you go out with me? 🌷</h2><button onclick='next()'>Yes 💗</button><button id='no'>No</button>`,
`<h2>What kind of date would you like?</h2>${['Coffee date','Dinner date','Movie date','Sunset date','Picnic date','Surprise me'].map(v=>`<button class=opt onclick='next()'>${v}</button>`).join('')}`,
`<h2>Where should we go?</h2>${['Your favorite spot','My favorite spot','Surprise me',"We'll decide together"].map(v=>`<button class=opt onclick='next()'>${v}</button>`).join('')}`,
`<h2>How can I reach you?</h2><select><option>Instagram</option><option>TikTok</option><option>WhatsApp</option><option>Discord</option><option>Telegram</option><option>Other</option></select><br><input placeholder='Your username'><br><button onclick='next()'>Send 💌</button>`,
`<h2>Thank you for saying yes, Jijul🍯 💗</h2><p>I'm looking forward to making memories together ✨</p><p>— From someone who likes you 💌</p>`
];
let i=0;const app=document.getElementById('app');
function draw(){app.innerHTML=pages[i];const n=document.getElementById('no');if(n){n.onmouseenter=n.ontouchstart=()=>{n.style.position='fixed';n.style.left=Math.random()*80+'vw';n.style.top=Math.random()*80+'vh';}}}
function next(){i=Math.min(i+1,pages.length-1);draw()}
window.next=next;draw();
document.getElementById('musicBtn').onclick=()=>document.getElementById('bgm').play();
